import torch
import torch.nn as nn
import torch.nn.functional as F

class Adapter(nn.Module):
    """
    Một Adapter Module đơn giản để tinh chỉnh các đặc trưng từ DINOv2.
    """
    def __init__(self, input_dim: int = 384, hidden_dim: int = 128):
        super().__init__()
        self.layer1 = nn.Linear(input_dim, hidden_dim)
        self.relu = nn.ReLU()
        self.layer2 = nn.Linear(hidden_dim, input_dim)

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        """
        Args:
            features (torch.Tensor): Tensor đặc trưng có shape [N, C],
                                     trong đó N là số patch, C là số chiều.
        
        Returns:
            torch.Tensor: Tensor đặc trưng đã được tinh chỉnh.
        """
        # Giữ lại giá trị gốc (residual connection) để học ổn định hơn
        residual = features
        
        x = self.layer1(features)
        x = self.relu(x)
        x = self.layer2(x)
        
        # Cộng lại với giá trị gốc
        output = x + residual
        return output

class CompactnessLoss(nn.Module):
    """
    Hàm loss dựa trên Cosine Similarity để gom cụm các đặc trưng "good".
    """
    def __init__(self):
        super().__init__()
        # CosineSimilarity tính toán sự tương đồng, loss là 1 - similarity
        self.cosine_similarity = nn.CosineSimilarity(dim=1)

    def forward(self, features1: torch.Tensor, features2: torch.Tensor) -> torch.Tensor:
        """
        Args:
            features1 (torch.Tensor): Batch các đặc trưng từ ảnh 1. Shape [B, C].
            features2 (torch.Tensor): Batch các đặc trưng từ ảnh 2. Shape [B, C].

        Returns:
            torch.Tensor: Giá trị loss (một số vô hướng).
        """
        # Tính trung bình cosine similarity trên toàn batch
        similarity = self.cosine_similarity(features1, features2)
        
        # Loss = 1 - similarity. Mục tiêu là đẩy similarity về 1 (loss về 0)
        loss = 1 - similarity.mean()
        return loss