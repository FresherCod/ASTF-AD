import torch
from torchvision.transforms import v2 as T
from PIL import Image
import os

# Dictionary để lưu các model đã được tải, tránh tải lại nhiều lần
LOADED_MODELS = {}

def get_dinov2_features(image_path: str, model_name: str = 'dinov2_vits14', device='cuda'):
    """
    Tải (nếu cần) một mô hình DINOv2 và trích xuất các feature map từ một ảnh.

    Args:
        image_path (str): Đường dẫn đến file ảnh.
        model_name (str): Tên của mô hình DINOv2 cần sử dụng.
                          'dinov2_vits14' là nhỏ và nhanh nhất.
                          'dinov2_vitb14' là cân bằng.
                          'dinov2_vitl14' là lớn và mạnh hơn.
        device (str): Thiết bị để chạy mô hình ('cuda' hoặc 'cpu').

    Returns:
        torch.Tensor: Một tensor chứa feature map của ảnh.
    """
    global LOADED_MODELS

    # 1. Tải mô hình DINOv2 (chỉ lần đầu tiên)
    if model_name not in LOADED_MODELS:
        print(f"\nLoading DINOv2 model '{model_name}' for the first time...")
        print("This may take a moment as the model is downloaded from the internet.")
        try:
            # torch.hub.load sẽ tự động tìm, tải và cache model
            model = torch.hub.load('facebookresearch/dinov2', model_name)
            model.eval().to(device)
            LOADED_MODELS[model_name] = model
            print("Model loaded and moved to", device)
        except Exception as e:
            print(f"Error loading model from PyTorch Hub: {e}")
            print("Please ensure you have an internet connection.")
            return None
    else:
        # Lấy model đã được tải từ cache
        model = LOADED_MODELS[model_name]

    # 2. Định nghĩa các phép biến đổi ảnh (phải giống hệt với DINOv2)
    transform = T.Compose([
            T.ToImage(),  # Chuyển PIL Image thành Image Tensor (uint8)
            T.ToDtype(torch.float32, scale=True), # Chuyển sang float32 và scale về [0, 1]
            T.Resize(256, interpolation=T.InterpolationMode.BICUBIC, antialias=True),
            T.CenterCrop(224),
            T.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
        ])

    # 3. Tải và biến đổi ảnh
    try:
        img = Image.open(image_path).convert('RGB')
        img_tensor = transform(img).unsqueeze(0).to(device)
    except FileNotFoundError:
        print(f"Error: Image not found at {image_path}")
        return None

    # 4. Trích xuất đặc trưng
    with torch.no_grad():
        # Lấy các feature map từ lớp cuối cùng của Transformer
        # `n=1` nghĩa là lấy 1 lớp cuối
        # `return_class_token=False` để chỉ lấy các patch token
        features_dict = model.get_intermediate_layers(img_tensor, n=1, return_class_token=False)
        
        # features_dict[0] là output của lớp cuối, có shape [1, num_patches, feature_dim]
        feature_map = features_dict[0].squeeze(0) # Bỏ batch dimension

        # Reshape lại để có dạng không gian [C, H, W]
        # Kích thước patch của DINOv2 là 14. Ảnh 224x224 -> feature map 16x16
        num_patches_side = 224 // 14
        feature_dim = feature_map.shape[-1]
        
        # Chuyển từ [num_patches, dim] -> [dim, num_patches] -> [dim, H_feat, W_feat]
        feature_map = feature_map.permute(1, 0).reshape(feature_dim, num_patches_side, num_patches_side)

    return feature_map

# Đoạn code để bạn có thể chạy file này trực tiếp để kiểm tra
if __name__ == '__main__':
    # Kiểm tra xem có GPU không
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"Using device: {device}")

    # Đường dẫn đến thư mục dự án
    PROJECT_ROOT = r"D:\scr\journal2"
    # Đường dẫn đến một ảnh mẫu để kiểm tra
    sample_image_path = os.path.join(PROJECT_ROOT, "datasets", "mvtec", "bottle", "test", "broken_large", "000.png")
    
    if not os.path.exists(sample_image_path):
        print(f"Error: Sample image path does not exist!\nPath: {sample_image_path}")
    else:
        print(f"Extracting features from sample image: {sample_image_path}")
        # Chạy thử với model nhỏ nhất
        features = get_dinov2_features(sample_image_path, model_name='dinov2_vits14', device=device)
        
        if features is not None:
            # Output shape sẽ là: torch.Size([384, 16, 16])
            # 384 = feature dimension cho vits14
            # 16x16 = kích thước không gian của feature map (224/14 = 16)
            print("Output feature map shape:", features.shape)