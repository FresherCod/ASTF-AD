import os
import torch
import numpy as np
from tqdm import tqdm
from PIL import Image
from torchvision.transforms import v2 as T
from sklearn.metrics import roc_auc_score
from scipy.ndimage import gaussian_filter

from feature_extractor import get_dinov2_features
from adapter import Adapter # Import class Adapter của bạn

def evaluate_with_adapter(category: str):
    """Đánh giá nhánh Semantic có sử dụng Adapter đã huấn luyện."""
    
    # --- Cấu hình ---
    MVTEC_DATA_PATH = r"D:\scr\journal2\datasets\mvtec"
    ADAPTER_SAVE_DIR = r"D:\scr\journal2\adapters"
    DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
    
    train_dir = os.path.join(MVTEC_DATA_PATH, category, "train", "good")
    test_dir = os.path.join(MVTEC_DATA_PATH, category, "test")
    adapter_path = os.path.join(ADAPTER_SAVE_DIR, f"{category}_adapter.pth")

    if not os.path.exists(adapter_path):
        print(f"Error: Adapter for '{category}' not found at {adapter_path}. Skipping.")
        return None

    print(f"--- Evaluating Semantic Branch with Adapter for: {category.upper()} ---")

    # --- Tải Adapter đã huấn luyện ---
    print(f"Loading adapter from {adapter_path}")
    adapter = Adapter().to(DEVICE)
    adapter.load_state_dict(torch.load(adapter_path))
    adapter.eval() # Chuyển sang chế độ đánh giá

    # --- Giai đoạn 1: Xây dựng Ngân hàng Đặc trưng (đã qua Adapter) ---
    print("Step 1: Building adapted feature memory bank...")
    train_features = []
    train_files = [os.path.join(train_dir, f) for f in os.listdir(train_dir) if f.endswith('.png')]

    with torch.no_grad(): # Tắt tính toán gradient cho toàn bộ quá trình
        for file_path in tqdm(train_files, desc="Extracting adapted train features"):
            # Lấy đặc trưng từ DINOv2
            feature_map = get_dinov2_features(file_path, device=DEVICE)
            
            # Reshape để cho vào Adapter
            C, H, W = feature_map.shape
            patches = feature_map.view(C, -1).T # Shape [H*W, C]
            
            # Cho qua Adapter
            adapted_patches = adapter(patches)
            
            train_features.append(adapted_patches)

    memory_bank = torch.cat(train_features, dim=0).to(DEVICE)
    print(f"Adapted memory bank created with shape: {memory_bank.shape}")


    # --- Giai đoạn 2: Đánh giá trên tập Test (logic giống hệt script trước) ---
    print("\nStep 2: Evaluating on test images...")
    # (Phần code này giống hệt script run_semantic_branch.py)
    test_files, ground_truth_masks, image_labels = [], [], []
    for defect_type in os.listdir(test_dir):
        # ... (Copy toàn bộ khối code chuẩn bị dữ liệu test từ script cũ)
        defect_dir = os.path.join(test_dir, defect_type)
        if not os.path.isdir(defect_dir): continue
        for file_name in os.listdir(defect_dir):
            if not file_name.endswith('.png'): continue
            image_path = os.path.join(defect_dir, file_name)
            test_files.append(image_path)
            is_good = (defect_type == 'good')
            image_labels.append(0 if is_good else 1)
            with Image.open(image_path) as img:
                img_size = img.size[::-1]
            if is_good:
                ground_truth_masks.append(np.zeros(img_size, dtype=np.uint8))
            else:
                mask_path_1 = image_path.replace('\\test\\', '\\ground_truth\\').replace('.png', '_mask.png')
                mask_path_2 = image_path.replace('\\test\\', '\\ground_truth\\')
                if os.path.exists(mask_path_1): mask_path = mask_path_1
                elif os.path.exists(mask_path_2): mask_path = mask_path_2
                else:
                    ground_truth_masks.append(np.zeros(img_size, dtype=np.uint8))
                    continue
                mask = np.array(Image.open(mask_path).convert('L'))
                if mask.shape != img_size:
                    mask = np.array(Image.open(mask_path).convert('L').resize(img_size[::-1]))
                ground_truth_masks.append((mask > 0).astype(np.uint8))


    image_scores, pixel_scores_all = [], []
    with torch.no_grad():
        for i, file_path in enumerate(tqdm(test_files, desc="Processing test images")):
            feature_map = get_dinov2_features(file_path, device=DEVICE)
            C, H, W = feature_map.shape
            patches = feature_map.view(C, -1).T
            
            # Cho đặc trưng test qua Adapter
            adapted_patches = adapter(patches)
            
            distances = torch.cdist(adapted_patches, memory_bank)
            min_distances, _ = torch.min(distances, dim=1)
            
            image_score = torch.max(min_distances).cpu().numpy()
            image_scores.append(image_score)
            
            anomaly_map = min_distances.view(H, W).cpu().numpy()
            target_size = ground_truth_masks[i].shape
            anomaly_map_resized = T.functional.resize(
                torch.tensor(anomaly_map).unsqueeze(0),
                size=list(target_size),
                interpolation=T.InterpolationMode.BILINEAR, antialias=True).squeeze(0).numpy()
            anomaly_map_smoothed = gaussian_filter(anomaly_map_resized, sigma=4)
            pixel_scores_all.append(anomaly_map_smoothed.flatten())

    
    # --- Giai đoạn 3: Tính toán AUROC (giống hệt script trước) ---
    print("\nStep 3: Calculating metrics...")
    image_auroc = roc_auc_score(image_labels, image_scores)
    gt_flat = np.concatenate([mask.flatten() for mask in ground_truth_masks])
    scores_flat = np.concatenate(pixel_scores_all)
    pixel_auroc = roc_auc_score(gt_flat, scores_flat)
    
    print(f"\n--- Results for {category.upper()} with Adapter ---")
    print(f"Image AUROC: {image_auroc:.4f}")
    print(f"Pixel AUROC: {pixel_auroc:.4f}")
    
    return {"category": category, "image_AUROC": image_auroc, "pixel_AUROC": pixel_auroc}


if __name__ == '__main__':
    results_with_adapter = []
    for cat in ['carpet', 'screw', 'zipper']:
        results_with_adapter.append(evaluate_with_adapter(category=cat))
    
    print("\n\n--- Summary with Adapter ---")
    for res in results_with_adapter:
        if res:
            print(f"Category: {res['category']}, Image AUROC: {res['image_AUROC']:.4f}, Pixel AUROC: {res['pixel_AUROC']:.4f}")