import os
from collections import Counter, defaultdict
from pathlib import Path

def summarize_folder_types(root_dir):
    """Liệt kê từng folder, thống kê dạng file & số lượng."""
    folder_summary = []

    for folder_path, subdirs, files in os.walk(root_dir):
        ext_counter = Counter()
        for f in files:
            ext = Path(f).suffix.lower() or "[no_ext]"
            ext_counter[ext] += 1

        folder_summary.append({
            "folder": folder_path,
            "num_files": len(files),
            "file_types": dict(ext_counter)
        })

    return folder_summary

def print_summary(summary):
    """In kết quả ra bảng dễ đọc."""
    print(f"{'Folder Path':<60} | {'#Files':>7} | {'File Types (count)':<40}")
    print("-"*120)
    for s in summary:
        file_types_str = ", ".join([f"{k}:{v}" for k, v in s["file_types"].items()])
        print(f"{s['folder']:<60} | {s['num_files']:>7} | {file_types_str:<40}")
    print("-"*120)

if __name__ == "__main__":
    root = input("📁 Nhập đường dẫn thư mục gốc cần quét: ").strip() or "."
    if not os.path.exists(root):
        print("❌ Thư mục không tồn tại.")
    else:
        summary = summarize_folder_types(root)
        print_summary(summary)
