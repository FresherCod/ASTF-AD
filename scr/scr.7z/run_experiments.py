import os
import sys
import torch
from torchvision.transforms import v2 as T
from anomalib.data import MVTecAD
from anomalib.models import Patchcore
from anomalib.engine import Engine
from rich.console import Console
from multiprocessing import freeze_support

def main():
    """Hàm chính chứa toàn bộ logic chạy thử nghiệm."""
    # --- Cấu hình ---
    PROJECT_ROOT = r"D:\scr\journal2"
    RESULTS_DIR = os.path.join(PROJECT_ROOT, "results")
    MVTEC_DATA_PATH = os.path.join(PROJECT_ROOT, "datasets", "mvtec")

    console = Console()

    try:
        categories = [d for d in os.listdir(MVTEC_DATA_PATH) if os.path.isdir(os.path.join(MVTEC_DATA_PATH, d))]
        if not categories:
            console.print(f"[bold red]Error: No categories found in {MVTEC_DATA_PATH}. Please check the path.[/bold red]")
            sys.exit(1)
    except FileNotFoundError:
        console.print(f"[bold red]Error: Dataset path not found at {MVTEC_DATA_PATH}. Please check the path.[/bold red]")
        sys.exit(1)

    # --- Vòng lặp thực thi ---
    for category in categories:
        console.print(f"\n[bold cyan]{'='*20} Running experiment for category: {category.upper()} {'='*20}[/bold cyan]")
        
        try:
            # 1. Khởi tạo Mô hình
            console.print("[yellow]Step 1: Initializing Patchcore model...[/yellow]")
            model = Patchcore(
                layers=["layer2", "layer3"],
                backbone="wide_resnet50_2",
                coreset_sampling_ratio=0.1,
                num_neighbors=9
            )

            # 2. Định nghĩa các phép biến đổi ảnh
            console.print("[yellow]Step 2: Defining image augmentations...[/yellow]")
            augmentations = T.Compose([
                T.Resize((256, 256), antialias=True),
                T.ToDtype(torch.float32, scale=True),
                T.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
            ])

            # 3. Khởi tạo Dữ liệu
            console.print(f"[yellow]Step 3: Initializing MVTecAD datamodule for '{category}'...[/yellow]")
            
            # <<< THAY ĐỔI ĐỂ GIẢM BỘ NHỚ >>>
            datamodule = MVTecAD(
                root=MVTEC_DATA_PATH,
                category=category,
                train_batch_size=8,  # Giảm từ 32 xuống 8
                eval_batch_size=8,   # Giảm từ 32 xuống 8
                num_workers=4,       # Giảm từ 8 xuống 4
                train_augmentations=augmentations,
                val_augmentations=augmentations,
                test_augmentations=augmentations
            )

            # 4. Khởi tạo Engine
            console.print("[yellow]Step 4: Initializing Anomalib Engine...[/yellow]")
            
            category_result_path = os.path.join(RESULTS_DIR, "Patchcore", "MVTec", category)
            
            engine = Engine(
                accelerator="auto",
                devices=1,
                default_root_dir=category_result_path,
                logger=False,
                enable_checkpointing=True,
                max_epochs=1,
            )

            # 5. Huấn luyện (Fit)
            console.print(f"[green]Step 5: Fitting model on '{category}' training data...[/green]")
            engine.fit(model=model, datamodule=datamodule)

            # 6. Đánh giá (Test)
            console.print(f"[green]Step 6: Testing model on '{category}' test data...[/green]")
            test_results = engine.test(model=model, datamodule=datamodule)
            
            console.print(f"[bold green]Successfully completed category: {category.upper()}[/bold green]")
            console.print(test_results)

        except Exception as e:
            console.print(f"[bold red]!!!!!! An error occurred while processing {category}. !!!!!![/bold red]")
            console.print_exception(show_locals=False)
            continue

    console.print(f"\n[bold blue]{'='*20} All experiments completed! Check results in {RESULTS_DIR} {'='*20}[/bold blue]")

if __name__ == '__main__':
    freeze_support() 
    main()