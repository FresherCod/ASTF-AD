import inspect
from anomalib.data import MVTecAD
from rich.console import Console

console = Console()

console.print("[bold green]--- Inspecting the MVTecAD class on your system ---[/bold green]")

# Cách 1: In ra toàn bộ tài liệu hướng dẫn của class
console.print("\n[yellow]Full help documentation:[/yellow]")
help(MVTecAD)

# Cách 2: In ra chữ ký (signature) của hàm __init__ một cách trực tiếp
console.print("\n[bold yellow]Direct __init__ signature:[/bold yellow]")
try:
    init_signature = inspect.signature(MVTecAD.__init__)
    console.print(str(init_signature))
except Exception as e:
    console.print(f"[red]Could not get signature directly: {e}[/red]")