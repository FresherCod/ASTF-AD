import os
import torch
import numpy as np
from tqdm import tqdm
from PIL import Image
from torchvision.transforms import v2 as T
from sklearn.metrics import roc_auc_score
from scipy.ndimage import gaussian_filter
import glob
import pandas as pd
from rich.console import Console
from rich.table import Table

# Các hàm và class khác không thay đổi...
from anomalib.models import Patchcore
from feature_extractor import get_dinov2_features
from adapter import Adapter

def normalize_map(anomaly_map: np.ndarray) -> np.ndarray:
    min_val = anomaly_map.min()
    max_val = anomaly_map.max()
    if max_val > min_val:
        return (anomaly_map - min_val) / (max_val - min_val)
    return anomaly_map

patchcore_transform = T.Compose([
    T.ToImage(),
    T.Resize((256, 256), antialias=True),
    T.ToDtype(torch.float32, scale=True),
    T.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
])

def run_fusion(category: str, fusion_method: str = 'add', alpha: float = 0.5):
    # Toàn bộ hàm run_fusion không thay đổi so với phiên bản trước
    # ...
    # (Giữ nguyên toàn bộ nội dung của hàm này)
    # ...
    # Nó vẫn trả về một dictionary kết quả
    # return { "category": category, "method": method_name, ... }
    """
    Chạy thử nghiệm kết hợp (Fusion) cho một category.
    
    Args:
        category (str): Tên category.
        fusion_method (str): Phương pháp kết hợp ('multiply', 'add', 'max', 'weighted_sum').
        alpha (float): Trọng số cho nhánh Patchcore trong 'weighted_sum'.
    """
    PROJECT_ROOT = r"D:\scr\journal2"
    RESULTS_DIR = os.path.join(PROJECT_ROOT, "results")
    MVTEC_DATA_PATH = os.path.join(PROJECT_ROOT, "datasets", "mvtec")
    ADAPTER_SAVE_DIR = os.path.join(PROJECT_ROOT, "adapters")
    DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
    
    base_category_path = os.path.join(RESULTS_DIR, "Patchcore", "MVTec", category)
    ckpt_files = glob.glob(os.path.join(base_category_path, "**", "*.ckpt"), recursive=True)
    if not ckpt_files: return None
    patchcore_weights_path = ckpt_files[0]
    adapter_path = os.path.join(ADAPTER_SAVE_DIR, f"{category}_adapter.pth")
    if not os.path.exists(adapter_path): return None

    method_name_log = f"{fusion_method.upper()}" + (f" (a={alpha})" if fusion_method=='weighted_sum' else '')
    print(f"\n--- Running FUSION (Method: {method_name_log}) for: {category.upper()} ---")

    patchcore_model = Patchcore.load_from_checkpoint(patchcore_weights_path)
    patchcore_model.to(DEVICE).eval()
    adapter = Adapter().to(DEVICE)
    adapter.load_state_dict(torch.load(adapter_path))
    adapter.eval()
    
    train_dir = os.path.join(MVTEC_DATA_PATH, category, "train", "good")
    train_files = [os.path.join(train_dir, f) for f in os.listdir(train_dir) if f.endswith('.png')]
    semantic_memory_bank = []
    with torch.no_grad():
        for file_path in train_files:
            feature_map = get_dinov2_features(file_path, device=DEVICE)
            C, H, W = feature_map.shape
            patches = feature_map.view(C, -1).T
            adapted_patches = adapter(patches)
            semantic_memory_bank.append(adapted_patches)
    semantic_memory_bank = torch.cat(semantic_memory_bank, dim=0)

    test_dir = os.path.join(MVTEC_DATA_PATH, category, "test")
    test_files, ground_truth_masks, image_labels = [], [], []
    for defect_type in os.listdir(test_dir):
        defect_dir = os.path.join(test_dir, defect_type)
        if not os.path.isdir(defect_dir): continue
        for file_name in os.listdir(defect_dir):
            if not file_name.endswith('.png'): continue
            image_path = os.path.join(defect_dir, file_name)
            test_files.append(image_path)
            is_good = (defect_type == 'good')
            image_labels.append(0 if is_good else 1)
            with Image.open(image_path) as img: img_size = img.size[::-1]
            if is_good:
                ground_truth_masks.append(np.zeros(img_size, dtype=np.uint8))
            else:
                mask_path_1 = image_path.replace('\\test\\', '\\ground_truth\\').replace('.png', '_mask.png')
                mask_path_2 = image_path.replace('\\test\\', '\\ground_truth\\')
                if os.path.exists(mask_path_1): mask_path = mask_path_1
                elif os.path.exists(mask_path_2): mask_path = mask_path_2
                else:
                    ground_truth_masks.append(np.zeros(img_size, dtype=np.uint8))
                    continue
                mask = np.array(Image.open(mask_path).convert('L'))
                if mask.shape != img_size: mask = np.array(Image.open(mask_path).convert('L').resize(img_size[::-1]))
                ground_truth_masks.append((mask > 0).astype(np.uint8))

    image_scores_fused, pixel_scores_fused = [], []
    
    with torch.no_grad():
        for i, file_path in enumerate(tqdm(test_files, desc=f"Fusing ({method_name_log})")):
            pil_image = Image.open(file_path).convert("RGB")
            target_size = ground_truth_masks[i].shape

            image_tensor = patchcore_transform(pil_image).unsqueeze(0).to(DEVICE)
            patchcore_result = patchcore_model(image_tensor)
            anomaly_map_patchcore = patchcore_result[2].squeeze().cpu().numpy()
            anomaly_map_patchcore_norm = normalize_map(anomaly_map_patchcore)

            feature_map = get_dinov2_features(file_path, device=DEVICE)
            C, H, W = feature_map.shape
            patches = feature_map.view(C, -1).T
            adapted_patches = adapter(patches)
            distances = torch.cdist(adapted_patches, semantic_memory_bank)
            min_distances, _ = torch.min(distances, dim=1)
            anomaly_map_semantic = min_distances.view(H, W).cpu().numpy()
            
            h_pc, w_pc = anomaly_map_patchcore.shape
            anomaly_map_semantic_resized = T.functional.resize(
                torch.tensor(anomaly_map_semantic).unsqueeze(0),
                size=[h_pc, w_pc],
                interpolation=T.InterpolationMode.BILINEAR, antialias=True).squeeze(0).numpy()
            anomaly_map_semantic_norm = normalize_map(anomaly_map_semantic_resized)
            
            if fusion_method == 'multiply':
                anomaly_map_fused = anomaly_map_patchcore_norm * anomaly_map_semantic_norm
            elif fusion_method == 'add':
                anomaly_map_fused = anomaly_map_patchcore_norm + anomaly_map_semantic_norm
            elif fusion_method == 'max':
                anomaly_map_fused = np.maximum(anomaly_map_patchcore_norm, anomaly_map_semantic_norm)
            elif fusion_method == 'weighted_sum':
                anomaly_map_fused = (alpha * anomaly_map_patchcore_norm) + ((1 - alpha) * anomaly_map_semantic_norm)
            else:
                raise ValueError(f"Unknown fusion method: {fusion_method}")

            anomaly_map_fused_resized = T.functional.resize(
                torch.tensor(anomaly_map_fused).unsqueeze(0),
                size=list(target_size),
                interpolation=T.InterpolationMode.BILINEAR, antialias=True).squeeze(0).numpy()
            anomaly_map_fused_smoothed = gaussian_filter(anomaly_map_fused_resized, sigma=4)
            
            image_scores_fused.append(np.max(anomaly_map_fused_smoothed))
            pixel_scores_fused.append(anomaly_map_fused_smoothed.flatten())

    image_auroc = roc_auc_score(image_labels, image_scores_fused)
    gt_flat = np.concatenate([mask.flatten() for mask in ground_truth_masks])
    scores_flat = np.concatenate(pixel_scores_fused)
    pixel_auroc = roc_auc_score(gt_flat, scores_flat)
    
    method_name = f"weighted_sum_a={alpha}" if fusion_method == 'weighted_sum' else fusion_method
    
    return {
        "category": category, 
        "method": method_name,
        "image_AUROC": image_auroc, 
        "pixel_AUROC": pixel_auroc
    }


if __name__ == '__main__':
    console = Console()
    
    # Các category để thử nghiệm
    categories_to_test = ['carpet', 'screw', 'zipper']
    
    # Các phương pháp fusion để thử nghiệm
    fusion_configs = [
        {'method': 'add'},
        {'method': 'max'},
        {'method': 'weighted_sum', 'alpha': 0.3},
        {'method': 'weighted_sum', 'alpha': 0.5},
        {'method': 'weighted_sum', 'alpha': 0.7},
        # Thêm lại 'multiply' để có trong bảng so sánh
        {'method': 'multiply'},
    ]

    all_fusion_results = []
    
    for cat in categories_to_test:
        for config in fusion_configs:
            result = run_fusion(category=cat, fusion_method=config['method'], alpha=config.get('alpha', 0.5))
            if result:
                all_fusion_results.append(result)

    if not all_fusion_results:
        console.print("[bold red]No fusion results were generated.[/bold red]")
    else:
        # <<< THAY ĐỔI LỚN: Cải thiện logic tạo và lưu file CSV >>>
        
        # 1. Tạo DataFrame gốc
        results_df = pd.DataFrame(all_fusion_results)
        results_df = results_df.round(4) # Làm tròn số

        # 2. Tạo Pivot Table để so sánh các phương pháp
        pivot_df = results_df.pivot_table(index='category', columns='method', values=['image_AUROC', 'pixel_AUROC'])
        
        # 3. Làm phẳng tiêu đề cột (MultiIndex to single index) cho file CSV đẹp hơn
        # Ví dụ: từ ('image_AUROC', 'add') -> 'image_AUROC_add'
        pivot_df.columns = [f'{val}_{method}' for val, method in pivot_df.columns]
        
        # 4. Tính trung bình cho mỗi cột và thêm vào cuối
        # Bỏ qua các cột có thể không phải số nếu có lỗi
        numeric_cols = pivot_df.select_dtypes(include=np.number).columns.tolist()
        pivot_df.loc['Average'] = pivot_df[numeric_cols].mean()
        
        # Làm tròn lại hàng Average
        pivot_df.loc['Average'] = pivot_df.loc['Average'].round(4)
        
        console.print("\n\n--- [bold green]Comprehensive Fusion Summary[/bold green] ---")
        # In ra terminal bằng to_markdown để có định dạng đẹp
        try:
            import tabulate
            print(pivot_df.to_markdown())
        except ImportError:
            print(pivot_df) # In bình thường nếu không có tabulate
        
        # 5. Lưu file CSV với định dạng đã làm phẳng
        PROJECT_ROOT = r"D:\scr\journal2"
        RESULTS_DIR = os.path.join(PROJECT_ROOT, "results")
        summary_path = os.path.join(RESULTS_DIR, "fusion_comparison_summary.csv")
        
        # .reset_index() để cột 'category' không bị mất khi lưu
        pivot_df.reset_index().to_csv(summary_path, index=False)
        
        console.print(f"\n[bold green]Comprehensive summary saved to: {summary_path}[/bold green]")