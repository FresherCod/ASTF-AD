import os
import torch
import numpy as np
from tqdm import tqdm
from PIL import Image
from torchvision.transforms import v2 as T
from sklearn.metrics import roc_auc_score
from scipy.ndimage import gaussian_filter

# Import hàm trích xuất đặc trưng của bạn
from feature_extractor import get_dinov2_features

def run_semantic_experiment(category: str):
    """Chạy thử nghiệm cho nhánh Semantic trên một category."""
    
    # --- Cấu hình ---
    MVTEC_DATA_PATH = r"D:\scr\journal2\datasets\mvtec"
    DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
    
    train_dir = os.path.join(MVTEC_DATA_PATH, category, "train", "good")
    test_dir = os.path.join(MVTEC_DATA_PATH, category, "test")

    print(f"--- Running Semantic Branch for: {category.upper()} ---")

    # --- Giai đoạn 1: Xây dựng Ngân hàng Đặc trưng (Memory Bank) ---
    print("Step 1: Building feature memory bank from training images...")
    train_features = []
    train_files = [os.path.join(train_dir, f) for f in os.listdir(train_dir) if f.endswith('.png')]

    for file_path in tqdm(train_files, desc="Extracting train features"):
        feature_map = get_dinov2_features(file_path, device=DEVICE)
        train_features.append(feature_map.view(feature_map.shape[0], -1).T)

    memory_bank = torch.cat(train_features, dim=0).to(DEVICE)
    print(f"Memory bank created with shape: {memory_bank.shape}")

    # --- Giai đoạn 2: Đánh giá trên tập Test ---
    print("\nStep 2: Evaluating on test images...")
    test_files = []
    ground_truth_masks = []
    image_labels = []

    # Lấy tất cả ảnh test và ground truth tương ứng
    for defect_type in os.listdir(test_dir):
        defect_dir = os.path.join(test_dir, defect_type)
        if not os.path.isdir(defect_dir): continue
        
        for file_name in os.listdir(defect_dir):
            if not file_name.endswith('.png'): continue
            
            image_path = os.path.join(defect_dir, file_name)
            test_files.append(image_path)
            
            is_good = (defect_type == 'good')
            image_labels.append(0 if is_good else 1)
            
            # <<< SỬA LỖI Ở ĐÂY >>>
            # Đọc ảnh để lấy kích thước thật
            with Image.open(image_path) as img:
                img_size = img.size[::-1] # (width, height) -> (height, width)

            if is_good:
                # Tạo mask rỗng với kích thước thật của ảnh
                ground_truth_masks.append(np.zeros(img_size, dtype=np.uint8))
            else:
                # Tìm đường dẫn mask
                # Một số category có đuôi _mask.png, số khác thì không, cần xử lý cả hai
                mask_path_1 = image_path.replace('\\test\\', '\\ground_truth\\').replace('.png', '_mask.png')
                mask_path_2 = image_path.replace('\\test\\', '\\ground_truth\\')
                
                if os.path.exists(mask_path_1):
                    mask_path = mask_path_1
                elif os.path.exists(mask_path_2):
                     mask_path = mask_path_2
                else:
                    # Nếu không tìm thấy mask, tạo mask rỗng và báo warning
                    print(f"Warning: Mask not found for {image_path}. Assuming empty mask.")
                    ground_truth_masks.append(np.zeros(img_size, dtype=np.uint8))
                    continue

                mask = np.array(Image.open(mask_path).convert('L'))
                # Đảm bảo mask có cùng kích thước với ảnh
                if mask.shape != img_size:
                    mask = np.array(Image.open(mask_path).convert('L').resize(img_size[::-1]))

                ground_truth_masks.append((mask > 0).astype(np.uint8))

    image_scores = []
    pixel_scores_all = []
    
    for i, file_path in enumerate(tqdm(test_files, desc="Processing test images")):
        feature_map = get_dinov2_features(file_path, device=DEVICE)
        C, H, W = feature_map.shape
        test_patches = feature_map.view(C, -1).T
        
        distances = torch.cdist(test_patches, memory_bank)
        min_distances, _ = torch.min(distances, dim=1)
        
        image_score = torch.max(min_distances).cpu().numpy()
        image_scores.append(image_score)
        
        anomaly_map = min_distances.view(H, W).cpu().numpy()
        
        # Lấy kích thước của ground truth mask tương ứng
        target_size = ground_truth_masks[i].shape
        
        anomaly_map_resized = T.functional.resize(
            torch.tensor(anomaly_map).unsqueeze(0),
            size=list(target_size),
            interpolation=T.InterpolationMode.BILINEAR,
            antialias=True
        ).squeeze(0).numpy()

        anomaly_map_smoothed = gaussian_filter(anomaly_map_resized, sigma=4)
        pixel_scores_all.append(anomaly_map_smoothed.flatten())

    # --- Giai đoạn 3: Tính toán AUROC ---
    print("\nStep 3: Calculating metrics...")
    
    image_auroc = roc_auc_score(image_labels, image_scores)
    
    # Nối các mảng lại một cách an toàn
    gt_flat = np.concatenate([mask.flatten() for mask in ground_truth_masks])
    scores_flat = np.concatenate(pixel_scores_all)
    
    pixel_auroc = roc_auc_score(gt_flat, scores_flat)
    
    print(f"\n--- Results for {category.upper()} ---")
    print(f"Image AUROC: {image_auroc:.4f}")
    print(f"Pixel AUROC: {pixel_auroc:.4f}")
    
    return {"category": category, "image_AUROC": image_auroc, "pixel_AUROC": pixel_auroc}


if __name__ == '__main__':
    # Chạy thử nghiệm trên các category khó
    results = []
    for cat in ['carpet', 'screw', 'zipper']:
        results.append(run_semantic_experiment(category=cat))
    
    print("\n\n--- Summary ---")
    for res in results:
        print(f"Category: {res['category']}, Image AUROC: {res['image_AUROC']:.4f}, Pixel AUROC: {res['pixel_AUROC']:.4f}")