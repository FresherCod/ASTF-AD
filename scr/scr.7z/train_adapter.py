import os
import torch
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from PIL import Image
from tqdm import tqdm

from feature_extractor import get_dinov2_features
from adapter import Adapter, CompactnessLoss

# Dataset tùy chỉnh để lấy ra các cặp ảnh "good"
class GoodImagePairDataset(Dataset):
    def __init__(self, root_dir):
        self.root_dir = root_dir
        self.image_files = [os.path.join(root_dir, f) for f in os.listdir(root_dir) if f.endswith('.png')]

    def __len__(self):
        return len(self.image_files)

    def __getitem__(self, idx):
        # Lấy ảnh thứ nhất
        img1_path = self.image_files[idx]
        
        # Lấy ngẫu nhiên ảnh thứ hai (không trùng với ảnh thứ nhất)
        rand_idx = torch.randint(0, len(self.image_files), (1,)).item()
        while rand_idx == idx:
            rand_idx = torch.randint(0, len(self.image_files), (1,)).item()
        img2_path = self.image_files[rand_idx]
        
        return img1_path, img2_path


def train_adapter_for_category(category: str, epochs: int = 10):
    """Huấn luyện Adapter cho một category cụ thể."""

    print(f"\n--- Training Adapter for: {category.upper()} ---")
    
    # --- Cấu hình ---
    MVTEC_DATA_PATH = r"D:\scr\journal2\datasets\mvtec"
    ADAPTER_SAVE_DIR = r"D:\scr\journal2\adapters"
    os.makedirs(ADAPTER_SAVE_DIR, exist_ok=True)
    DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'

    train_dir = os.path.join(MVTEC_DATA_PATH, category, "train", "good")

    # --- Chuẩn bị Data ---
    dataset = GoodImagePairDataset(root_dir=train_dir)
    # Batch size nhỏ vì chúng ta không cần nhiều dữ liệu cùng lúc
    dataloader = DataLoader(dataset, batch_size=4, shuffle=True, num_workers=0)

    # --- Khởi tạo Model, Loss, Optimizer ---
    adapter = Adapter().to(DEVICE)
    criterion = CompactnessLoss()
    optimizer = optim.Adam(adapter.parameters(), lr=1e-4)
    
    # Đóng băng DINOv2 (vì get_dinov2_features đã có torch.no_grad())
    
    # --- Vòng lặp Huấn luyện ---
    adapter.train()
    for epoch in range(epochs):
        total_loss = 0.0
        progress_bar = tqdm(dataloader, desc=f"Epoch {epoch+1}/{epochs}")

        for img1_paths, img2_paths in progress_bar:
            optimizer.zero_grad()

            batch_features1 = []
            batch_features2 = []
            
            # Trích xuất đặc trưng cho batch
            # (Làm tuần tự để tránh OOM trên DINOv2)
            for i in range(len(img1_paths)):
                # Lấy feature map [C, H, W]
                feat1_map = get_dinov2_features(img1_paths[i], device=DEVICE)
                feat2_map = get_dinov2_features(img2_paths[i], device=DEVICE)
                
                # Làm phẳng và lấy trung bình các patch -> 1 vector/ảnh
                feat1_vec = feat1_map.mean(dim=[1, 2])
                feat2_vec = feat2_map.mean(dim=[1, 2])

                batch_features1.append(feat1_vec)
                batch_features2.append(feat2_vec)

            features1 = torch.stack(batch_features1)
            features2 = torch.stack(batch_features2)
            
            # Cho qua Adapter
            adapted_features1 = adapter(features1)
            adapted_features2 = adapter(features2)
            
            # Tính Loss
            loss = criterion(adapted_features1, adapted_features2)
            
            # Backpropagation
            loss.backward()
            optimizer.step()
            
            total_loss += loss.item()
            progress_bar.set_postfix(loss=f"{loss.item():.6f}")

        avg_loss = total_loss / len(dataloader)
        print(f"Epoch {epoch+1}/{epochs}, Average Loss: {avg_loss:.6f}")
    
    # --- Lưu Adapter đã huấn luyện ---
    adapter_save_path = os.path.join(ADAPTER_SAVE_DIR, f"{category}_adapter.pth")
    torch.save(adapter.state_dict(), adapter_save_path)
    print(f"Adapter for '{category}' saved to {adapter_save_path}")


if __name__ == '__main__':
    # Huấn luyện adapter cho các category chúng ta đã thử nghiệm
    train_adapter_for_category(category='carpet', epochs=10)
    train_adapter_for_category(category='screw', epochs=10)
    train_adapter_for_category(category='zipper', epochs=10)
    
    print("\nAll adapter training complete.")