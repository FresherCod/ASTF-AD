import os
import sys
import torch
import pandas as pd
from torchvision.transforms import v2 as T
from anomalib.data import MVTecAD
from anomalib.models import Patchcore
from anomalib.engine import Engine
from rich.console import Console
from rich.table import Table
from multiprocessing import freeze_support
import glob

def main():
    """
    Chạy lại bước test cho tất cả các category bằng cách tải lại các trọng số
    đã huấn luyện và tổng hợp kết quả vào file CSV.
    """
    # --- Cấu hình ---
    PROJECT_ROOT = r"D:\scr\journal2"
    RESULTS_DIR = os.path.join(PROJECT_ROOT, "results")
    MVTEC_DATA_PATH = os.path.join(PROJECT_ROOT, "datasets", "mvtec")

    console = Console()

    try:
        # Lấy danh sách các category từ thư mục kết quả đã chạy
        base_result_path = os.path.join(RESULTS_DIR, "Patchcore", "MVTec")
        categories = sorted([d for d in os.listdir(base_result_path) if os.path.isdir(os.path.join(base_result_path, d))])
        if not categories:
            console.print(f"[bold red]Error: No category result folders found in {base_result_path}. Please run experiments first.[/bold red]")
            sys.exit(1)
    except FileNotFoundError:
        console.print(f"[bold red]Error: Base result path not found at {base_result_path}.[/bold red]")
        sys.exit(1)

    all_results = []

    # --- Vòng lặp thực thi ---
    for category in categories:
        console.print(f"\n[bold cyan]{'='*20} Testing category: {category.upper()} {'='*20}[/bold cyan]")
        
        try:
            # 1. Tìm đường dẫn đến file trọng số (.ckpt)
            console.print("[yellow]Step 1: Finding checkpoint file...[/yellow]")
            category_result_path = os.path.join(base_result_path, category)
            
            # Tìm file .ckpt. Thường là 'last.ckpt' hoặc 'model.ckpt'
            ckpt_files = glob.glob(os.path.join(category_result_path, "**", "*.ckpt"), recursive=True)
            if not ckpt_files:
                console.print(f"[bold red]Error: No .ckpt file found for category '{category}'. Skipping.[/bold red]")
                all_results.append({'category': category, 'image_AUROC': 'CKPT_NOT_FOUND'})
                continue
            
            ckpt_path = ckpt_files[0] # Lấy file đầu tiên tìm thấy
            console.print(f"Found checkpoint: {ckpt_path}")

            # 2. Khởi tạo Mô hình. Không cần khởi tạo lại, Engine sẽ tự load.
            console.print("[yellow]Step 2: Initializing Patchcore model...[/yellow]")
            model = Patchcore(
                layers=["layer2", "layer3"],
                backbone="wide_resnet50_2"
            )

            # 3. Định nghĩa các phép biến đổi ảnh
            console.print("[yellow]Step 3: Defining image augmentations...[/yellow]")
            augmentations = T.Compose([
                T.Resize((256, 256), antialias=True),
                T.ToDtype(torch.float32, scale=True),
                T.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
            ])

            # 4. Khởi tạo Dữ liệu
            console.print(f"[yellow]Step 4: Initializing MVTecAD datamodule for '{category}'...[/yellow]")
            datamodule = MVTecAD(
                root=MVTEC_DATA_PATH,
                category=category,
                train_batch_size=8,
                eval_batch_size=8,
                num_workers=4,
                train_augmentations=augmentations,
                val_augmentations=augmentations,
                test_augmentations=augmentations
            )

            # 5. Khởi tạo Engine
            console.print("[yellow]Step 5: Initializing Anomalib Engine...[/yellow]")
            engine = Engine(
                accelerator="auto",
                devices=1,
                logger=False, # Quan trọng: Vẫn tắt logger
            )

            # 6. Đánh giá (Test) - Chỉ chạy bước này
            console.print(f"[green]Step 6: Testing model on '{category}' test data...[/green]")
            test_results = engine.test(model=model, datamodule=datamodule, ckpt_path=ckpt_path)
            
            if test_results:
                result_dict = test_results[0]
                result_dict['category'] = category
                all_results.append(result_dict)
            
            console.print(f"[bold green]Successfully tested category: {category.upper()}[/bold green]")
            console.print(test_results)

        except Exception as e:
            console.print(f"[bold red]!!!!!! An error occurred while processing {category}. !!!!!![/bold red]")
            console.print_exception(show_locals=False)
            all_results.append({'category': category, 'image_AUROC': 'ERROR'})
            continue

    # 7. Tổng hợp và lưu kết quả
    if all_results:
        console.print(f"\n[bold blue]{'='*20} Final Results Summary {'='*20}[/bold blue]")
        
        results_df = pd.DataFrame(all_results).sort_values(by='category').reset_index(drop=True)
        cols = ['category'] + [col for col in results_df.columns if col != 'category']
        results_df = results_df[cols]

        numeric_cols = results_df.select_dtypes(include=['number']).columns
        if not numeric_cols.empty:
            mean_series = results_df[numeric_cols].mean()
            mean_series['category'] = 'Average'
            mean_df = pd.DataFrame(mean_series).transpose()
            results_df = pd.concat([results_df, mean_df], ignore_index=True)
            results_df[numeric_cols] = results_df[numeric_cols].round(4)

        table = Table(title="PatchCore Baseline on MVTec AD (Re-tested)")
        for col in results_df.columns:
            table.add_column(col, justify="center")
        for _, row in results_df.iterrows():
            table.add_row(*[str(val) for val in row.values])
        console.print(table)
        
        summary_path = os.path.join(RESULTS_DIR, "patchcore_mvtec_summary_retested.csv")
        results_df.to_csv(summary_path, index=False)
        console.print(f"\n[bold green]Summary saved to: {summary_path}[/bold green]")


if __name__ == '__main__':
    freeze_support() 
    main()