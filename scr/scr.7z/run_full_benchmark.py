import os
import sys
import torch
import numpy as np
from tqdm import tqdm
from PIL import Image
from torchvision.transforms import v2 as T
from sklearn.metrics import roc_auc_score
from scipy.ndimage import gaussian_filter
import glob
import pandas as pd
from rich.console import Console
from rich.table import Table

# Import tất cả các module cần thiết
from anomalib.models import Patchcore
from feature_extractor import get_dinov2_features
from adapter import Adapter, CompactnessLoss
from torch.utils.data import Dataset, DataLoader
import torch.optim as optim

# --- Phần Code Huấn luyện Adapter (Lấy từ train_adapter.py) ---
class GoodImagePairDataset(Dataset):
    def __init__(self, root_dir):
        self.root_dir = root_dir
        self.image_files = [os.path.join(root_dir, f) for f in os.listdir(root_dir) if f.endswith('.png')]
    def __len__(self): return len(self.image_files)
    def __getitem__(self, idx):
        img1_path = self.image_files[idx]
        rand_idx = torch.randint(0, len(self.image_files), (1,)).item()
        while rand_idx == idx: rand_idx = torch.randint(0, len(self.image_files), (1,)).item()
        img2_path = self.image_files[rand_idx]
        return img1_path, img2_path

def train_adapter_for_category(category: str, epochs: int = 10):
    # (Hàm này giữ nguyên logic như file train_adapter.py)
    print(f"\n--- Training Adapter for: {category.upper()} ---")
    PROJECT_ROOT = r"D:\scr\journal2"
    MVTEC_DATA_PATH = os.path.join(PROJECT_ROOT, "datasets", "mvtec")
    ADAPTER_SAVE_DIR = os.path.join(PROJECT_ROOT, "adapters")
    os.makedirs(ADAPTER_SAVE_DIR, exist_ok=True)
    DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
    train_dir = os.path.join(MVTEC_DATA_PATH, category, "train", "good")
    dataset = GoodImagePairDataset(root_dir=train_dir)
    dataloader = DataLoader(dataset, batch_size=4, shuffle=True, num_workers=0)
    adapter = Adapter().to(DEVICE)
    criterion = CompactnessLoss()
    optimizer = optim.Adam(adapter.parameters(), lr=1e-4)
    adapter.train()
    for epoch in range(epochs):
        total_loss = 0.0
        progress_bar = tqdm(dataloader, desc=f"Epoch {epoch+1}/{epochs}")
        for img1_paths, img2_paths in progress_bar:
            optimizer.zero_grad()
            batch_features1, batch_features2 = [], []
            for i in range(len(img1_paths)):
                feat1_map = get_dinov2_features(img1_paths[i], device=DEVICE)
                feat2_map = get_dinov2_features(img2_paths[i], device=DEVICE)
                batch_features1.append(feat1_map.mean(dim=[1, 2]))
                batch_features2.append(feat2_map.mean(dim=[1, 2]))
            features1 = torch.stack(batch_features1)
            features2 = torch.stack(batch_features2)
            adapted_features1, adapted_features2 = adapter(features1), adapter(features2)
            loss = criterion(adapted_features1, adapted_features2)
            loss.backward(); optimizer.step()
            total_loss += loss.item()
            progress_bar.set_postfix(loss=f"{loss.item():.6f}")
        print(f"Epoch {epoch+1}/{epochs}, Average Loss: {total_loss / len(dataloader):.6f}")
    adapter_save_path = os.path.join(ADAPTER_SAVE_DIR, f"{category}_adapter.pth")
    torch.save(adapter.state_dict(), adapter_save_path)
    print(f"Adapter for '{category}' saved to {adapter_save_path}")

# --- Phần Code Đánh giá (Lấy từ run_voted_strategy.py) ---
def normalize_map(anomaly_map: np.ndarray) -> np.ndarray: # Giữ nguyên
    min_val, max_val = anomaly_map.min(), anomaly_map.max()
    return (anomaly_map - min_val) / (max_val - min_val) if max_val > min_val else anomaly_map

patchcore_transform = T.Compose([ # Giữ nguyên
    T.ToImage(), T.Resize((256, 256), antialias=True), T.ToDtype(torch.float32, scale=True),
    T.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
])

# <<< 1. BẢN ĐỒ CHIẾN LƯỢC MỞ RỘNG >>>
STRATEGY_MAP = {
    # Ưu tiên Semantic cho texture / vật thể hữu cơ
    'carpet':   'semantic_adapter',
    'grid':     'semantic_adapter',
    'leather':  'semantic_adapter',
    'wood':     'semantic_adapter',
    'hazelnut': 'semantic_adapter',
    # Ưu tiên Fusion giữ thế mạnh PatchCore cho vật thể cứng, lỗi nhỏ
    'metal_nut':'fusion_weighted_sum_0.7',
    'screw':    'fusion_weighted_sum_0.7',
    'tile':     'fusion_weighted_sum_0.7',
    'toothbrush':'fusion_weighted_sum_0.7',
    'transistor':'fusion_weighted_sum_0.7',
    # Dùng Fusion cân bằng cho các trường hợp còn lại
    'bottle':   'fusion_add',
    'cable':    'fusion_add',
    'capsule':  'fusion_add',
    'pill':     'fusion_add',
    'zipper':   'fusion_add', # Chuyển zipper sang add để thử nghiệm
}

def run_expert_selection_test(category: str, patchcore_model, adapter, semantic_memory_bank):
    # Hàm này bây giờ nhận các model đã được tải sẵn để tối ưu
    PROJECT_ROOT = r"D:\scr\journal2"
    MVTEC_DATA_PATH = os.path.join(PROJECT_ROOT, "datasets", "mvtec")
    DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
    
    strategy = STRATEGY_MAP.get(category, 'fusion_add')
    
    test_dir = os.path.join(MVTEC_DATA_PATH, category, "test")
    test_files, ground_truth_masks, image_labels = [], [], []
    # (Code chuẩn bị data không đổi)
    for defect_type in os.listdir(test_dir):
        defect_dir = os.path.join(test_dir, defect_type)
        if not os.path.isdir(defect_dir): continue
        for file_name in os.listdir(defect_dir):
            if not file_name.endswith('.png'): continue
            image_path = os.path.join(defect_dir, file_name)
            test_files.append(image_path)
            is_good = (defect_type == 'good'); image_labels.append(0 if is_good else 1)
            with Image.open(image_path) as img: img_size = img.size[::-1]
            if is_good: ground_truth_masks.append(np.zeros(img_size, dtype=np.uint8))
            else:
                mask_path_1 = image_path.replace('\\test\\', '\\ground_truth\\').replace('.png', '_mask.png')
                mask_path_2 = image_path.replace('\\test\\', '\\ground_truth\\')
                if os.path.exists(mask_path_1): mask_path = mask_path_1
                elif os.path.exists(mask_path_2): mask_path = mask_path_2
                else: ground_truth_masks.append(np.zeros(img_size, dtype=np.uint8)); continue
                mask = np.array(Image.open(mask_path).convert('L'))
                if mask.shape != img_size: mask = np.array(Image.open(mask_path).convert('L').resize(img_size[::-1]))
                ground_truth_masks.append((mask > 0).astype(np.uint8))

    image_scores_final, pixel_scores_final = [], []
    with torch.no_grad():
        for i, file_path in enumerate(tqdm(test_files, desc=f"Applying Strategy ({strategy})")):
            # (Logic bên trong vòng lặp này không đổi)
            pil_image = Image.open(file_path).convert("RGB"); target_size = ground_truth_masks[i].shape
            feature_map_sem = get_dinov2_features(file_path, device=DEVICE)
            patches_sem = feature_map_sem.view(feature_map_sem.shape[0], -1).T
            adapted_patches = adapter(patches_sem)
            distances = torch.cdist(adapted_patches, semantic_memory_bank)
            min_distances, _ = torch.min(distances, dim=1)
            anomaly_map_semantic_raw = min_distances.view(feature_map_sem.shape[1], feature_map_sem.shape[2]).cpu().numpy()
            if strategy == 'semantic_adapter': final_map_unresized = anomaly_map_semantic_raw
            else:
                image_tensor = patchcore_transform(pil_image).unsqueeze(0).to(DEVICE)
                patchcore_result = patchcore_model(image_tensor)
                anomaly_map_patchcore = patchcore_result[2].squeeze().cpu().numpy()
                if strategy == 'patchcore': final_map_unresized = anomaly_map_patchcore
                else:
                    anomaly_map_patchcore_norm = normalize_map(anomaly_map_patchcore)
                    h_pc, w_pc = anomaly_map_patchcore.shape
                    anomaly_map_semantic_resized = T.functional.resize(torch.tensor(anomaly_map_semantic_raw).unsqueeze(0), size=[h_pc, w_pc], interpolation=T.InterpolationMode.BILINEAR, antialias=True).squeeze(0).numpy()
                    anomaly_map_semantic_norm = normalize_map(anomaly_map_semantic_resized)
                    if strategy == 'fusion_add': final_map_unresized = anomaly_map_patchcore_norm + anomaly_map_semantic_norm
                    elif strategy == 'fusion_weighted_sum_0.7':
                        alpha = 0.7; final_map_unresized = (alpha * anomaly_map_patchcore_norm) + ((1 - alpha) * anomaly_map_semantic_norm)
            final_map_resized = T.functional.resize(torch.tensor(final_map_unresized).unsqueeze(0), size=list(target_size), interpolation=T.InterpolationMode.BILINEAR, antialias=True).squeeze(0).numpy()
            final_map_smoothed = gaussian_filter(final_map_resized, sigma=4)
            image_scores_final.append(np.max(final_map_smoothed)); pixel_scores_final.append(final_map_smoothed.flatten())

    image_auroc = roc_auc_score(image_labels, image_scores_final)
    gt_flat = np.concatenate([m.flatten() for m in ground_truth_masks])
    scores_flat = np.concatenate(pixel_scores_final)
    pixel_auroc = roc_auc_score(gt_flat, scores_flat)
    return { "category": category, "applied_strategy": strategy, "image_AUROC": image_auroc, "pixel_AUROC": pixel_auroc }

def main():
    """Hàm chính để chạy toàn bộ benchmark."""
    console = Console()
    PROJECT_ROOT = r"D:\scr\journal2"
    RESULTS_DIR = os.path.join(PROJECT_ROOT, "results")
    MVTEC_DATA_PATH = os.path.join(PROJECT_ROOT, "datasets", "mvtec")
    ADAPTER_SAVE_DIR = os.path.join(PROJECT_ROOT, "adapters")
    DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'

    all_categories = sorted([d for d in os.listdir(MVTEC_DATA_PATH) if os.path.isdir(os.path.join(MVTEC_DATA_PATH, d))])
    
    final_results = []

    for category in all_categories:
        console.print(f"\n[bold magenta]Processing Category: {category.upper()}[/bold magenta]")

        # 1. Huấn luyện Adapter nếu cần
        adapter_path = os.path.join(ADAPTER_SAVE_DIR, f"{category}_adapter.pth")
        if not os.path.exists(adapter_path):
            train_adapter_for_category(category=category, epochs=10)
        else:
            print(f"Adapter for '{category}' already exists. Skipping training.")

        # 2. Tải các model cần thiết cho category này
        base_category_path = os.path.join(RESULTS_DIR, "Patchcore", "MVTec", category)
        ckpt_files = glob.glob(os.path.join(base_category_path, "**", "*.ckpt"), recursive=True)
        if not ckpt_files:
            console.print(f"[bold red]PatchCore weights not found for {category}. Skipping.[/bold red]")
            continue
        
        patchcore_model = Patchcore.load_from_checkpoint(ckpt_files[0]).to(DEVICE).eval()
        adapter = Adapter().to(DEVICE).eval()
        adapter.load_state_dict(torch.load(adapter_path))

        # 3. Xây dựng memory bank cho category này
        train_dir = os.path.join(MVTEC_DATA_PATH, category, "train", "good")
        semantic_memory_bank = []
        with torch.no_grad():
            for file_path in tqdm(os.listdir(train_dir), desc=f"Building bank for {category}"):
                feature_map = get_dinov2_features(os.path.join(train_dir, file_path), device=DEVICE)
                patches = feature_map.view(feature_map.shape[0], -1).T
                semantic_memory_bank.append(adapter(patches))
        semantic_memory_bank = torch.cat(semantic_memory_bank, dim=0)

        # 4. Chạy đánh giá
        result = run_expert_selection_test(category, patchcore_model, adapter, semantic_memory_bank)
        if result:
            final_results.append(result)

    # 5. Tổng hợp và so sánh với baseline
    if final_results:
        # Lấy kết quả của hệ thống
        voted_df = pd.DataFrame(final_results).round(4)
        voted_df = voted_df.set_index('category')

        # Đọc kết quả baseline từ file
        baseline_path = os.path.join(RESULTS_DIR, "patchcore_mvtec_summary_retested.csv")
        if not os.path.exists(baseline_path):
            console.print(f"[bold red]Baseline file not found at {baseline_path}. Cannot compare.[/bold red]")
            return
        
        baseline_df = pd.read_csv(baseline_path)
        baseline_df = baseline_df.rename(columns={'image_AUROC': 'baseline_image_AUROC', 'pixel_AUROC': 'baseline_pixel_AUROC'})
        baseline_df = baseline_df.set_index('category')

        # Kết hợp hai bảng lại
        comparison_df = voted_df.join(baseline_df[['baseline_image_AUROC', 'baseline_pixel_AUROC']])
        comparison_df = comparison_df.round(4)

        # Tính trung bình
        comparison_df.loc['Average'] = comparison_df.mean(numeric_only=True).round(4)

        console.print("\n\n--- [bold green]OVERALL PERFORMANCE COMPARISON[/bold green] ---")
        try:
            import tabulate
            print(comparison_df.to_markdown())
        except ImportError:
            print(comparison_df)

        # Lưu file so sánh cuối cùng
        summary_path = os.path.join(RESULTS_DIR, "final_benchmark_comparison.csv")
        comparison_df.reset_index().to_csv(summary_path, index=False)
        console.print(f"\n[bold green]Final comparison summary saved to: {summary_path}[/bold green]")


if __name__ == '__main__':
    # freeze_support() không cần thiết nếu num_workers=0 trong training
    main()