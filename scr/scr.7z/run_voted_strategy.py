import os
import torch
import numpy as np
from tqdm import tqdm
from PIL import Image
from torchvision.transforms import v2 as T
from sklearn.metrics import roc_auc_score
from scipy.ndimage import gaussian_filter
import glob
import pandas as pd
from rich.console import Console
from rich.table import Table

from anomalib.models import Patchcore
from feature_extractor import get_dinov2_features
from adapter import Adapter

# Các hàm tiện ích không đổi
def normalize_map(anomaly_map: np.ndarray) -> np.ndarray:
    min_val, max_val = anomaly_map.min(), anomaly_map.max()
    return (anomaly_map - min_val) / (max_val - min_val) if max_val > min_val else anomaly_map

patchcore_transform = T.Compose([
    T.ToImage(), T.Resize((256, 256), antialias=True), T.ToDtype(torch.float32, scale=True),
    T.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
])

# <<< 1. BẢN ĐỒ CHIẾN LƯỢC (STRATEGY MAP) >>>
# Dựa trên phân tích kết quả thực nghiệm toàn diện
# Key: category, Value: Tên phương pháp sẽ áp dụng
STRATEGY_MAP = {
    'carpet':   'semantic_adapter', # Tốt nhất cả Image & Pixel AUROC
    'screw':    'fusion_weighted_sum_0.7', # Giữ được Pixel AUROC cao nhất của PatchCore
    'zipper':   'semantic_adapter', # Tốt nhất cả Image & Pixel AUROC
    'default':  'fusion_add' # Một lựa chọn an toàn cho các category khác
}

def run_expert_selection_test(category: str):
    """
    Chạy thử nghiệm với chiến lược lựa chọn chuyên gia cho một category.
    """
    # --- Cấu hình ---
    PROJECT_ROOT = r"D:\scr\journal2"
    RESULTS_DIR = os.path.join(PROJECT_ROOT, "results")
    MVTEC_DATA_PATH = os.path.join(PROJECT_ROOT, "datasets", "mvtec")
    ADAPTER_SAVE_DIR = os.path.join(PROJECT_ROOT, "adapters")
    DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'

    # --- Lấy chiến lược từ bản đồ ---
    strategy = STRATEGY_MAP.get(category, STRATEGY_MAP['default'])
    print(f"\n--- Running EXPERT SELECTION for: {category.upper()} (Strategy: {strategy.upper()}) ---")

    # --- Tải Models ---
    # (Tải tất cả các model cần thiết, vì một số chiến lược cần cả hai)
    base_category_path = os.path.join(RESULTS_DIR, "Patchcore", "MVTec", category)
    ckpt_files = glob.glob(os.path.join(base_category_path, "**", "*.ckpt"), recursive=True)
    if not ckpt_files: return None
    patchcore_model = Patchcore.load_from_checkpoint(ckpt_files[0]).to(DEVICE).eval()

    adapter_path = os.path.join(ADAPTER_SAVE_DIR, f"{category}_adapter.pth")
    if not os.path.exists(adapter_path): return None
    adapter = Adapter().to(DEVICE).eval()
    adapter.load_state_dict(torch.load(adapter_path))
    
    # Xây dựng semantic memory bank
    train_dir = os.path.join(MVTEC_DATA_PATH, category, "train", "good")
    semantic_memory_bank = []
    with torch.no_grad():
        for file_path in os.listdir(train_dir):
            feature_map = get_dinov2_features(os.path.join(train_dir, file_path), device=DEVICE)
            patches = feature_map.view(feature_map.shape[0], -1).T
            semantic_memory_bank.append(adapter(patches))
    semantic_memory_bank = torch.cat(semantic_memory_bank, dim=0)

    # --- Chuẩn bị dữ liệu Test ---
    test_dir = os.path.join(MVTEC_DATA_PATH, category, "test")
    test_files, ground_truth_masks, image_labels = [], [], []
    # (Code chuẩn bị data không đổi)
    for defect_type in os.listdir(test_dir):
        defect_dir = os.path.join(test_dir, defect_type)
        if not os.path.isdir(defect_dir): continue
        for file_name in os.listdir(defect_dir):
            if not file_name.endswith('.png'): continue
            image_path = os.path.join(defect_dir, file_name)
            test_files.append(image_path)
            is_good = (defect_type == 'good'); image_labels.append(0 if is_good else 1)
            with Image.open(image_path) as img: img_size = img.size[::-1]
            if is_good:
                ground_truth_masks.append(np.zeros(img_size, dtype=np.uint8))
            else:
                mask_path_1 = image_path.replace('\\test\\', '\\ground_truth\\').replace('.png', '_mask.png')
                mask_path_2 = image_path.replace('\\test\\', '\\ground_truth\\')
                if os.path.exists(mask_path_1): mask_path = mask_path_1
                elif os.path.exists(mask_path_2): mask_path = mask_path_2
                else:
                    ground_truth_masks.append(np.zeros(img_size, dtype=np.uint8)); continue
                mask = np.array(Image.open(mask_path).convert('L'))
                if mask.shape != img_size: mask = np.array(Image.open(mask_path).convert('L').resize(img_size[::-1]))
                ground_truth_masks.append((mask > 0).astype(np.uint8))


    image_scores_final, pixel_scores_final = [], []
    
    with torch.no_grad():
        for i, file_path in enumerate(tqdm(test_files, desc=f"Applying Strategy ({strategy})")):
            pil_image = Image.open(file_path).convert("RGB")
            target_size = ground_truth_masks[i].shape

            # --- Lấy Anomaly Map từ các nhánh ---
            # Luôn tính map của nhánh Semantic vì hầu hết các chiến lược đều cần nó
            feature_map = get_dinov2_features(file_path, device=DEVICE)
            patches = feature_map.view(feature_map.shape[0], -1).T
            adapted_patches = adapter(patches)
            distances = torch.cdist(adapted_patches, semantic_memory_bank)
            min_distances, _ = torch.min(distances, dim=1)
            anomaly_map_semantic_raw = min_distances.view(feature_map.shape[1], feature_map.shape[2]).cpu().numpy()

            # Nếu chiến lược là 'semantic_adapter', chỉ cần dùng map này
            if strategy == 'semantic_adapter':
                final_map_unresized = anomaly_map_semantic_raw
            else:
                # Các chiến lược còn lại đều cần map của PatchCore
                image_tensor = patchcore_transform(pil_image).unsqueeze(0).to(DEVICE)
                patchcore_result = patchcore_model(image_tensor)
                anomaly_map_patchcore = patchcore_result[2].squeeze().cpu().numpy()
                
                if strategy == 'patchcore':
                    final_map_unresized = anomaly_map_patchcore
                else: # Các chiến lược Fusion
                    anomaly_map_patchcore_norm = normalize_map(anomaly_map_patchcore)
                    
                    h_pc, w_pc = anomaly_map_patchcore.shape
                    anomaly_map_semantic_resized = T.functional.resize(
                        torch.tensor(anomaly_map_semantic_raw).unsqueeze(0),
                        size=[h_pc, w_pc],
                        interpolation=T.InterpolationMode.BILINEAR, antialias=True).squeeze(0).numpy()
                    anomaly_map_semantic_norm = normalize_map(anomaly_map_semantic_resized)

                    if strategy == 'fusion_add':
                        final_map_unresized = anomaly_map_patchcore_norm + anomaly_map_semantic_norm
                    elif strategy == 'fusion_weighted_sum_0.7':
                        alpha = 0.7
                        final_map_unresized = (alpha * anomaly_map_patchcore_norm) + ((1 - alpha) * anomaly_map_semantic_norm)
                    # Có thể thêm các chiến lược fusion khác ở đây
            
            # Resize map cuối cùng về kích thước gốc, làm mượt và lưu
            final_map_resized = T.functional.resize(
                torch.tensor(final_map_unresized).unsqueeze(0),
                size=list(target_size),
                interpolation=T.InterpolationMode.BILINEAR, antialias=True).squeeze(0).numpy()
            final_map_smoothed = gaussian_filter(final_map_resized, sigma=4)
            
            image_scores_final.append(np.max(final_map_smoothed))
            pixel_scores_final.append(final_map_smoothed.flatten())

    image_auroc = roc_auc_score(image_labels, image_scores_final)
    gt_flat = np.concatenate([mask.flatten() for mask in ground_truth_masks])
    scores_flat = np.concatenate(pixel_scores_final)
    pixel_auroc = roc_auc_score(gt_flat, scores_flat)
    
    return { "category": category, "applied_strategy": strategy, "image_AUROC": image_auroc, "pixel_AUROC": pixel_auroc }


if __name__ == '__main__':
    console = Console()
    categories_to_test = ['carpet', 'screw', 'zipper']
    final_results = []
    
    for cat in categories_to_test:
        result = run_expert_selection_test(category=cat)
        if result:
            final_results.append(result)

    if final_results:
        results_df = pd.DataFrame(final_results).round(4)
        
        console.print("\n\n--- [bold green]Final Results of the Expert Selection System[/bold green] ---")
        table = Table(title="Voted Strategy Results")
        for col in results_df.columns:
            table.add_column(col, justify="center")
        for _, row in results_df.iterrows():
            table.add_row(*[str(val) for val in row.values])
        console.print(table)
        
        # Lưu file CSV cuối cùng
        PROJECT_ROOT = r"D:\scr\journal2"
        RESULTS_DIR = os.path.join(PROJECT_ROOT, "results")
        summary_path = os.path.join(RESULTS_DIR, "final_voted_strategy_summary.csv")
        results_df.to_csv(summary_path, index=False)
        console.print(f"\n[bold green]Final summary saved to: {summary_path}[/bold green]")